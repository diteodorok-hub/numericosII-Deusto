clc; clear; close all;

%% Definición del problema
f = @(x) exp(x).*sin(x);   % función (mejor que x^2 para ver errores)
a = 0;
b = 1;

%Simpson 1/3 necesita par
%3/8 múltiplo de 3
%Boole múltiplo de 4

N = [4 8 12 16 20 40];   % tú defines los nodos
%N = 2.^(2:7);

I_exacta = integral_referencia(f, a, b);

%% Inicialización
I_trap = zeros(size(N));
I_simp13 = zeros(size(N));
I_simp38 = zeros(size(N));
I_boole = zeros(size(N));

err_trap = zeros(size(N));
err_simp13 = zeros(size(N));
err_simp38 = zeros(size(N));
err_boole = zeros(size(N));

h = zeros(size(N));

%% Bucle principal
for k = 1:length(N)

    n = N(k);

    % Ajustes necesarios por método
    n_trap = n;

    n_simp13 = n;
    if mod(n_simp13,2) ~= 0
        n_simp13 = n_simp13 + 1;
    end

    n_simp38 = n;
    r = mod(n_simp38,3);
    if r ~= 0
        n_simp38 = n_simp38 + (3 - r);
    end

    n_boole = n;
    r4 = mod(n_boole,4);
    if r4 ~= 0
        n_boole = n_boole + (4 - r4);
    end

    % Métodos
    I_trap(k)   = trapecio_compuesto(f,a,b,n_trap);
    I_simp13(k) = simpson13_compuesto(f,a,b,n_simp13);
    I_simp38(k) = simpson38_compuesto(f,a,b,n_simp38);
    I_boole(k)  = boole_compuesto(f,a,b,n_boole);

    % Errores
    err_trap(k)   = abs(I_exacta - I_trap(k));
    err_simp13(k) = abs(I_exacta - I_simp13(k));
    err_simp38(k) = abs(I_exacta - I_simp38(k));
    err_boole(k)  = abs(I_exacta - I_boole(k));

    % paso
    h(k) = (b-a)/n;

end

%% Mostrar resultados
disp('Integral exacta:')
disp(I_exacta)

disp('Aproximaciones:')
disp([I_trap; I_simp13; I_simp38; I_boole])

%% Grafica 1: Error
figure;
plot(N, err_trap, '-o','LineWidth',2); hold on;
plot(N, err_simp13, '-s','LineWidth',2);
plot(N, err_simp38, '-^','LineWidth',2);
plot(N, err_boole, '-d','LineWidth',2);

legend('Trapecio','Simpson 1/3','Simpson 3/8','Boole');
title('Error vs numero de subintervalos');
xlabel('N');
ylabel('Error');
grid on;

%% Grafica 2: Precision (log-log)
figure;
loglog(h, err_trap, '-o','LineWidth',2); hold on;
loglog(h, err_simp13, '-s','LineWidth',2);
loglog(h, err_simp38, '-^','LineWidth',2);
loglog(h, err_boole, '-d','LineWidth',2);

legend('Trapecio','Simpson 1/3','Simpson 3/8','Boole');
title('Precision de los metodos (log-log)');
xlabel('h');
ylabel('Error');
grid on;

% valor de la integral
figure;
plot(N, I_trap, '-o','LineWidth',2); hold on;
plot(N, I_simp13, '-s','LineWidth',2);
plot(N, I_simp38, '-^','LineWidth',2);
plot(N, I_boole, '-d','LineWidth',2);
yline(I_exacta, 'k','LineWidth',2);  % línea de referencia
grid on;
xlabel('Numero de subintervalos (N)');
ylabel('Valor de la integral');
title('Comparacion de metodos: valor de la integral');
legend('Trapecio','Simpson 1/3','Simpson 3/8','Boole','Exacta','Location','best');