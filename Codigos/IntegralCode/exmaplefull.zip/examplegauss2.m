clc; clear; close all;

f = @(x) exp(x).*sin(x);
a = 0;
b = 1;

I_exacta = integral_referencia(f, a, b);

I = gauss2(f, a, b);

error = abs(I_exacta - I);

disp('Integral exacta:')
disp(I_exacta)

disp('Gauss 2 nodos:')
disp(I)

disp('Error:')
disp(error)