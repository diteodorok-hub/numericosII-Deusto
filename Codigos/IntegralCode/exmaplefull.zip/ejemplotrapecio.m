clc; clear; close all;
f = @(x) x.^2;
a = 0;
b = 1;
n = 10;

%I = trapecio_compuesto(f, a, b, n);
%I = simpson38_compuesto(f, a, b, n);
I_exacta = integral_referencia(f, a, b);
I = boole_compuesto(f, a, b, n);
disp(I)
disp(I_exacta)