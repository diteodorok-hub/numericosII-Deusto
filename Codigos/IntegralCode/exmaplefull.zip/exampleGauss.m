clc; clear; close all;

f = @(x) exp(x).*sin(x);
a = 0;
b = 1;

N = 2:10;   % Gauss puede usar cualquier n

I_exacta = integral_referencia(f, a, b);

for k = 1:length(N)

    n = N(k);

    I(k) = gauss_legendre(f, a, b, n);

    error(k) = abs(I_exacta - I(k));

    % aquí h no es tan natural, pero usamos 1/n
    h(k) = 1/n;

end

%% Mostrar resultados
disp('Integral exacta:')
disp(I_exacta)

disp('Aproximaciones:')
disp(I)

%% Grafica error
figure;
plot(N, error, '-o','LineWidth',2);
xlabel('n (numero de nodos)');
ylabel('Error');
title('Error Gauss-Legendre');
grid on;

%% Grafica precision (log-log)
figure;
loglog(h, error, '-o','LineWidth',2);
xlabel('1/n');
ylabel('Error');
title('Precision Gauss-Legendre (log-log)');
grid on;

figure;
semilogy(N, error, '-o','LineWidth',2);

xlabel('Numero de nodos (n)');
ylabel('Error');
title('Error Gauss-Legendre');

grid on;

figure;
loglog(1./N, error, '-o','LineWidth',2);

set(gca,'XDir','reverse')  

xlabel('h ~ 1/n');
ylabel('Error');
title('Precision Gauss-Legendre (log-log)');

grid on;