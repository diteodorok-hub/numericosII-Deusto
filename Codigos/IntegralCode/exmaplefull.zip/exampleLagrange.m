clc; clear; close all;
%x_data = [0 1 2];
%y_data = [1 2 0];
%x_eval = linspace(0,2,100);

%%%%%%%%%%%%%%
n = 10;
a = -1; b = 1;
k = 0:n;
x_data = (a+b)/2 + (b-a)/2 * cos((2*k+1)/(2*(n+1))*pi);
y_data = rand(1, n+1);
x_eval = linspace(a,b,200);
%%%%%%%%%%%%%%%%

p = lagrange_interpolacion(x_data, y_data, x_eval);
P = lagrange_simbolico(x_data, y_data)

plot(x_data, y_data, 'o', x_eval, p, '-')
legend('Datos','Interpolación')